import React, { useState } from 'react';

const Header = () => {
  // State for header text and dark mode
  const [headerText, setHeaderText] = useState("Jon Catipon's page");
  const [isDark, setIsDark] = useState(false);

  const toggleDarkMode = () => {
    setIsDark(prev => !prev);
    // We toggle the class on the body element to affect the whole page
    document.body.classList.toggle('dark-mode');
  };

  const changeHeader = () => {
    setHeaderText("Welcome to My Javascript Enhanced Page!");
  };

  const showMessage = () => {
    alert("Thanks for visiting my website!");
  };

  return (
    <div className="container mx-auto p-3">
      {/* Control Buttons */}
      <div className="flex space-x-3 mb-3">
        <button
          onClick={toggleDarkMode}
          className="bg-gray-800 text-white p-2 rounded hover:bg-gray-600 transition duration-150"
        >
          {isDark ? 'Turn Light Mode' : 'Turn Dark Mode'}
        </button>
        <button
          onClick={showMessage}
          className="bg-blue-500 text-white p-2 rounded hover:bg-blue-700 transition duration-150"
        >
          Show Message
        </button>
        <button
          onClick={changeHeader}
          className="bg-green-500 text-white p-2 rounded hover:bg-green-700 transition duration-150"
        >
          Change Header
        </button>
      </div>

      {/* Main Header */}
      <header className="text-center p-4 bg-red-400 text-white rounded-t-lg">
        <h1 id="main-header" className="text-3xl font-bold">{headerText}</h1>
      </header>
    </div>
  );
};

export default Header;
