import React from 'react';

const Navbar = () => {
  const navItems = [
    { name: 'Home', href: '#' },
    { name: 'About', href: '#' },
    { name: 'Projects', href: '#' },
  ];

  return (
    <nav className="bg-gray-800 p-3 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <a className="text-white text-xl font-semibold" href="#">Navigation</a>
        <div className="flex space-x-4">
          {navItems.map((item) => (
            <a key={item.name} className="text-gray-300 hover:text-white transition duration-150" href={item.href}>
              {item.name}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
