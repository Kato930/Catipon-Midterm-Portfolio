import React from 'react';
import Header from './components/Header';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';

// Injecting the complex dark mode styles as a component to preserve original CSS behavior
const DarkModeStyle = () => (
    <style dangerouslySetInnerHTML={{__html: `
        .dark-mode { background-color: #121212 !important; color: #ffffff !important; }
        .dark-mode * { color: #ffffff !important; }
        .dark-mode .container, .dark-mode .row, .dark-mode .col, .dark-mode article, .dark-mode section, .dark-mode aside { background-color: #121212 !important; }
        .dark-mode nav { background-color: #000 !important; }
        .dark-mode header, .dark-mode footer { background-color: #121212 !important; }
        .dark-mode button { color: #000 !important; }
    `}} />
);

const App = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <DarkModeStyle />
      <Header />
      <Navbar />
      <div className="flex-grow">
        {/* We render the Home page content here */}
        <Home />
      </div>
      <Footer />
    </div>
  );
};

export default App;
