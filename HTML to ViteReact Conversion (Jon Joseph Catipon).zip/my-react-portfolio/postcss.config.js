export default {
  plugins: {
    '@tailwindcss/postcss': {}, // <-- Changed this line
    autoprefixer: {},
  },
}
